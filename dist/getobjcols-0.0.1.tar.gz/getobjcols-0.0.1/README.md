#  getobjcols package Usage

This is a simple package to get a list of object columns in your pandas dataframe. Just call the function named 'obj_cols' from the package and send a pandas dataframe as input and it shall return a list of all object columns.

`from getobjcols import obj_fi`

`obj_fi.obj_cols(data)`

